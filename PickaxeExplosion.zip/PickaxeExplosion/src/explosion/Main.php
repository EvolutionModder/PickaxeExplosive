<?php

namespace explosion;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;

use pocketmine\item\Item;
use pocketmine\block\Block;
use pocketmine\level\Position;

use pocketmine\math\Vector3;
use pocketmine\{Server, Player};
use pocketmine\event\player\PlayerJoinEvent;

use pocketmine\inventory\{BaseInventory, PlayerInventory};

class Main extends PluginBase implements Listener {
	
	
	public function onEnable(){
		Server::getInstance()->getPluginManager()->registerEvents($this, $this);
	}
	
	public function onBreak(BlockBreakEvent $ev){
		
		$player = $ev->getPlayer();
		$item = $player->getInventory()->getItemInHand();
		
		if($item->getID() == 278 && $item->getCustomName() == "§5Picareta Explosive X"){
			$X = $ev->getBlock()->getX();
			$Y = $ev->getBlock()->getY();
			$Z = $ev->getBlock()->getZ();
			Server::getInstance()->getLevelByName("world")->setBlockIdAt($X+ 1, $Y, $Z, 0);
			$this->getServer()->getLevelByName("world")->setBlockIdAt($X-1, $Y, $Z, 0);
                $this->getServer()->getLevelByName("world")->setBlockIdAt($X, $Y, $Z+1, 0);
                     $this->getServer()->getLevelByName("world")->setBlockIdAt($X, $Y, $Z-1, 0);
      $this->getServer()->getLevelByName("world")->setBlockIdAt($X-1, $Y, $Z-1, 0);
           $this->getServer()->getLevelByName("world")->setBlockIdAt($X-1, $Y, $Z+1, 0);
                $this->getServer()->getLevelByName("world")->setBlockIdAt($X+1, $Y, $Z+1, 0);
                     $this->getServer()->getLevelByName("world")->setBlockIdAt($X+1, $Y, $Z-1, 0);
       $this->getServer()->getLevelByName("world")->setBlockIdAt($X+1, $Y+1, $Z, 0);
           $this->getServer()->getLevelByName("world")->setBlockIdAt($X-1, $Y+1, $Z, 0);
                $this->getServer()->getLevelByName("world")->setBlockIdAt($X, $Y+1, $Z+1, 0);
                     $this->getServer()->getLevelByName("world")->setBlockIdAt($X, $Y+1, $Z-1, 0);
      $this->getServer()->getLevelByName("world")->setBlockIdAt($X-1, $Y+1, $Z-1, 0);
           $this->getServer()->getLevelByName("world")->setBlockIdAt($X-1, $Y+1, $Z+1, 0);
                $this->getServer()->getLevelByName("world")->setBlockIdAt($X+1, $Y+1, $Z+1, 0);
                     $this->getServer()->getLevelByName("world")->setBlockIdAt($X+1, $Y+1, $Z-1, 0);
$this->getServer()->getLevelByName("world")->setBlockIdAt($X+1, $Y-1, $Z, 0);
           $this->getServer()->getLevelByName("world")->setBlockIdAt($X-1, $Y-1, $Z, 0);
                $this->getServer()->getLevelByName("world")->setBlockIdAt($X, $Y-1, $Z+1, 0);
                     $this->getServer()->getLevelByName("world")->setBlockIdAt($X, $Y-1, $Z-1, 0);
      $this->getServer()->getLevelByName("world")->setBlockIdAt($X-1, $Y-1, $Z-1, 0);
           $this->getServer()->getLevelByName("world")->setBlockIdAt($X-1, $Y-1, $Z+1, 0);
                $this->getServer()->getLevelByName("world")->setBlockIdAt($X+1, $Y-1, $Z+1, 0);
                     $this->getServer()->getLevelByName("world")->setBlockIdAt($X+1, $Y-1, $Z-1, 0);
                      $this->getServer()->getLevelByName("world")->setBlockIdAt($X, $Y-1, $Z, 0);
                     $this->getServer()->getLevelByName("world")->setBlockIdAt($X, $Y+1, $Z, 0);
                     
             $drops = [];
             $count = 9;
             $i = $ev->getBlock()->getID();
             $m = $ev->getBlock()->getDamage();
             $drops[] = new Item($i, $m, $count);
             $ev->setDrops($drops);
		}
	}
	
	public function onJoin(PlayerJoinEvent $ev){
		
		$player = $ev->getPlayer();
		$inv = $player->getInventory();
		
		$item = Item::get(278, 0, 1);
		$item->setCustomName("§5Picareta Explosive X");
		$inv->addItem($item);
		
	}
	
}